from .pjsekai_scores import *

__doc__ = pjsekai_scores.__doc__
if hasattr(pjsekai_scores, "__all__"):
    __all__ = pjsekai_scores.__all__